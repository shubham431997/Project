const express = require("express")
const db = require("../db")
const utils = require("../utils")
const router = express.Router()



router.post("/product", (request, response) => {
  const { user_id, product_id } = request.body;
  const statement = `INSERT INTO orders (user_id, product_id) VALUES (?, ?)`;
  db.query(statement, [user_id, product_id], (error, result) => {
    if (error) {
      response.status(500).json({ error: 'Error placing the order' });
    } else {
      response.status(201).json({ message: 'Order placed successfully' });
    }
  });
});



  module.exports = router
  
  