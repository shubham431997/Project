const express = require("express")
const db = require("../db")
const utils = require("../utils")
const multer = require('multer')
const upload = multer({ dest: 'uploads/' })

const router = express.Router()

//Show all Products
router.get("/",(request,response)=>{
    console.log("User get called...");
    db.query("select * from products",(error,result)=>{
        response.send(utils.createResult(error, result))
        }
    )
})

//Insert new Product
router.post("/", upload.single('image'), (request, response) => {
    console.log("User post called...");
    const filename = request.file.filename
    const { name, description, price } = request.body;

    const query = "INSERT INTO products (image, name, description, price) VALUES (?, ?, ?, ?)";
    const values = [filename, name, description, price];

    db.query(query, values, (error, result) => {
        response.send(utils.createResult(error, result))
    });
});


module.exports = router

