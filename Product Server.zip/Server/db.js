const mysql = require("mysql")

const connection = mysql.createConnection({
  user: "root",
  password: "shubham@11",
  host: "localhost",
  port: 3306,
  database: "db",
})

connection.connect()
console.log("Database is connected...");
module.exports = connection
