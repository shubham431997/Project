package com.event.utils;

import com.event.entity.Cart;
import com.event.entity.User;
import com.google.gson.JsonObject;



import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface API {
    String BASE_URL = "http://192.168.168.205:4000";

    @POST("/user/register")
    Call<JsonObject> registerUser(@Body User user);

    @POST("/user/login")
    Call<JsonObject> loginUser(@Body User user);


    @GET("/product/")
    Call<JsonObject> getAllProducts();


    @GET("/cart/{id}")
    Call<JsonObject> getusercart(@Path("id") int id);

    @POST("/cart/product")
    Call<JsonObject> AddToCart(@Body Cart cart);
}
