package com.event.fragment;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.event.R;
import com.event.adapter.ProductListAdapter;
import com.event.entity.Product;
import com.event.utils.RetrofitClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CartFragment extends Fragment {
    RecyclerView recyclerView;
    ProductListAdapter productListAdapter;
    List<Product> productsList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerView);
        productsList = new ArrayList<>();
        productListAdapter = new ProductListAdapter(getContext(), productsList);

        recyclerView.setAdapter(productListAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1));
    }

    @Override
    public void onResume() {
        super.onResume();
        getUserCart();
    }
    private void getUserCart() {
        productsList.clear();
        int id = getContext().getSharedPreferences("product", Context.MODE_PRIVATE).getInt("uid",0);
        RetrofitClient.getInstance().getApi().getusercart(id).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(response.body().getAsJsonObject().get("status").getAsString().equals("success")){
                    JsonArray jsonArray = response.body().getAsJsonObject().get("data").getAsJsonArray();
                    for (JsonElement e :jsonArray) {
                        Product product = new Product();
                        product.setId(e.getAsJsonObject().get("id").getAsInt());
                        product.setImage(e.getAsJsonObject().get("image").getAsString());
                        product.setName(e.getAsJsonObject().get("name").getAsString());
                        product.setDescription(e.getAsJsonObject().get("description").getAsString());
                        product.setPrice(e.getAsJsonObject().get("price").getAsString());
                        productsList.add(product);

                    }
                    productListAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getContext(), "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }
}