package com.event.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.event.R;
import com.event.entity.Cart;
import com.event.entity.Product;
import com.event.entity.User;
import com.event.utils.API;
import com.event.utils.RetrofitClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailsActivity extends AppCompatActivity {
    TextView textName, textDescription, textPrice;
    ImageView imageView;
    Product product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        textName = findViewById(R.id.textName);
        textDescription = findViewById(R.id.textDescription);
        textPrice = findViewById(R.id.textPrice);
        imageView = findViewById(R.id.imageView);
        product = (Product) getIntent().getSerializableExtra("product");

        getProductDetails();
    }

    private void getProductDetails() {
        textName.setText("Name  :" + product.getName());
        textDescription.setText("Desriptions:  :" + product.getDescription());
        textPrice.setText("Event Price  :" + product.getPrice());
        Glide.with(this).load(API.BASE_URL + "/" + product.getImage()).into(imageView);
    }

    public void AddToCart(View view) {

        int uid = getSharedPreferences("product",MODE_PRIVATE).getInt("uid",0);
        int mid = product.getId();

        Cart cart = new Cart();
        cart.setUser_id(uid);
        cart.setProduct_id(mid);



        RetrofitClient.getInstance().getApi().AddToCart(cart).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(response.body().getAsJsonObject().get("status").getAsString().equals("success")){
                    Toast.makeText(DetailsActivity.this, "Product Added into cart", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(DetailsActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }

}